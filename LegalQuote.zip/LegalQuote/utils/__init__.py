# Questo file è necessario per rendere la cartella utils un pacchetto Python
